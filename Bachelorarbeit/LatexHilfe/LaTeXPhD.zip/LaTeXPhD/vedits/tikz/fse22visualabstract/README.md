﻿# How to use the visual abstract

## Dependencies

- `../colors.tex`
- `../vedits-colors.tex`
- `../vedits.tex`

## Setup

Include `defines.tex` at the top of your file.
Behind that include `boxes.tex` or provide your own boxes.
Including the `vabstract.tex` below the inclusion of `defines.tex` will draw the abstract at the included location as a `tikzpicture`.
The defines provide many commands that are intended be redefined before each inclusion to enable animations, custom annotations, or other rewrites of the abstract.

### Animations

Renew the `\vaAnim*` commands.

Example:
```tex

% Show Abstract
\renewcommand{\vaAnimAbstractBefore}{\uncover<2->}
\renewcommand{\vaAnimAbstractAfter}{\uncover<2->}
\renewcommand{\vaAnimEdgeParseConcreteBefore}{\uncover<2->}
\renewcommand{\vaAnimEdgeParseConcreteAfter}{\uncover<2->}

\renewcommand{\vaAnimClassificationUnknown}{\vaNoAnim}
\renewcommand{\vaAnimEdgeClassifyUnknown}{\vaNoAnim}

\renewcommand{\vaAnimAbstractDiff}{\invisible}
\renewcommand{\vaAnimClassification}{\invisible}

\renewcommand{\vaAnimEdgeParseConcreteDiff}{\invisible}
\renewcommand{\vaAnimEdgeDiffAbstractBefore}{\invisible}
\renewcommand{\vaAnimEdgeDiffAbstractAfter}{\invisible}
\renewcommand{\vaAnimEdgeClassify}{\invisible}
```