# LaTeXPhDMath
Notation and definitions shared between my papers and talks
